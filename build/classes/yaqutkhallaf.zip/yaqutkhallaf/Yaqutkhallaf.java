/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yaqutkhallaf;

import java.util.Scanner;

/**
 *
 * @author student
 */
public class Yaqutkhallaf {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.println("Welcome to the CoffeeMachine");
        while(true){
                    System.out.println("What do you want to do");
         System.out.println("(1)Add water coffee"+"(2)make Coffee"+"(3)Cheek machine"+"(4)Exit");
int choice=in.nextInt();
switch(choice){
    case 1:
        Addwatercoffee();
    break;
      case 2:
      makeCoffee();
    break;
      case 3:
         Cheekmachine(); 
    break;
       case 4:
       System.out.println("Exit");
    break;
       default:
      System.out.println("Invalied choice");
    break;
    
}
        }
    }   // TODO code application logic here
    
 
    private static void Addwatercoffee() {
          Scanner in=new Scanner(System.in);
      System.out.println("What do you want to add"+"(1)Water"+"(2)beans");
      int choice=in.nextInt();
      
    }

    private static void makeCoffee() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static void Cheekmachine() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
