/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yaqutkhallaf;

/**
 *
 * @author student
 */
public class CoffeeMachine {
   
     WasteTry wast=new WasteTry(100,200);
     WaterTank water =new WaterTank(1000,1000);
     BeanContainer beans =new BeanContainer(1500,2000);
   Ginder gider=new Ginder(200) ;
    public static int count;

   

   
   

   




    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
